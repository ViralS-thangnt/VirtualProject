@extends('layout.master')

@section('content')

ログアウト

ログアウトしました。


@stop