@extends('layout.master')
@section('content')

<section class="contents">
	<h2>ログアウト</h2>

	<section>
		<p>
			ログアウトしました。
		</p>
	</section>
</section>


@stop