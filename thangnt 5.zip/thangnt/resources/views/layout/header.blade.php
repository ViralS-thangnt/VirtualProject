<header>
	<nav class="home-menu pure-menu pure-menu-horizontal relative">
		<h1 class="pure-menu-heading"><a href="">社員管理システム</a></h1>
		@yield('header-items')
		
			
		@include('user.header-items')
		
	</nav>


</header>

