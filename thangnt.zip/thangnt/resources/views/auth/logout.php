@extends('layout.master')

@section('content')

Ban da logout thanh cong !


@stop