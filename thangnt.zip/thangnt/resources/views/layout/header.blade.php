<header>
	<nav class="home-menu pure-menu pure-menu-horizontal relative">
		<h1 class="pure-menu-heading"><a href="">社員管理システム</a></h1>
		@yield('header-items')
		
		
			
		<a href="{!! url(ADD_USER_PATH) !!}" class="pure-menu-link">Thêm mới</a>
		<a href="{!! url(LOGOUT) !!}" class="pure-menu-link">Logout</a>
		
		</nav>


	</nav>


</header>

