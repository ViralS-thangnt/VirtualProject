<footer>
Employer Management System
</footer>